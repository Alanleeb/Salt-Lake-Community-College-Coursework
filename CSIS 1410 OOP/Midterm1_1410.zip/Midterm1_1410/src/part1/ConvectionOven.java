/*Aaron Templeton
 * Midterm 1 - CSIS 1410
 * 
 */
package part1;

public class ConvectionOven extends Oven {

	public ConvectionOven(double s) {
		super(s);

	}

	public void heatFood() {
		System.out.println("heating food by circulating hot air");
	}
}
